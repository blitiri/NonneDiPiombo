using UnityEngine;
using System.Collections.Generic;

namespace Rewired.Integration.BehaviorDesigner {

    using global::BehaviorDesigner.Runtime;
    using global::BehaviorDesigner.Runtime.Tasks;

    // Actions

    #region Base Classes

    public abstract class RewiredPlayerBDAction : Action {
        
        [Tooltip("The Rewired Player Id. To use the System Player, enter any value < 0 or 9999999.")]
        public SharedInt playerId;

        protected Player Player {
            get {
                if(playerId.Value < 0 || playerId.Value == Rewired.Consts.systemPlayerId) return ReInput.players.GetSystemPlayer();
                return ReInput.players.GetPlayer(playerId.Value);
            }
        }

        public override void OnReset() {
            base.OnReset();
            playerId = 0;
        }

        public override TaskStatus OnUpdate() {
            if(!ValidateVars()) return TaskStatus.Failure;
            return DoUpdate();
        }

        public abstract TaskStatus DoUpdate();

        protected virtual bool ValidateVars() {
            if(playerId.IsNone) {
                Debug.LogError("Rewired Player Id must be assigned!");
                return false;
            }
            if(playerId.Value != Rewired.Consts.systemPlayerId && playerId.Value >= ReInput.players.playerCount) {
                Debug.LogError("Rewired Player Id is out of range!");
                return false;
            }
            return true;
        }
    }

    public abstract class RewiredPlayerActionBDAction : RewiredPlayerBDAction {

        [Tooltip("The Action name string. Must match Action name exactly in the Rewired Input Manager.")]
        public SharedString actionName;

        public override void OnReset() {
            base.OnReset();
            actionName = string.Empty;
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(actionName.IsNone || string.IsNullOrEmpty(actionName.Value) || ReInput.mapping.GetActionId(actionName.Value) < 0) {
                Debug.LogError("Invalid Rewired Action name\"" + actionName.Value + "\"!");
                return false;
            }
            return true;
        }
    }

    public abstract class RewiredPlayerActionGetFloatBDAction : RewiredPlayerActionBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0f;
        }

        protected TaskStatus UpdateStoreValue(float newValue) {
            if(newValue != storeValue.Value) { // value changed
                // Store new value
                storeValue.Value = newValue;
            }

            return TaskStatus.Success;
        }
    }

    public abstract class RewiredPlayerActionGetBoolBDAction : RewiredPlayerActionBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = false;
        }

        protected TaskStatus UpdateStoreValue(bool newValue) {
            if(newValue != storeValue.Value) { // value changed
                // Store new value
                storeValue.Value = newValue;
            }

            return TaskStatus.Success;
        }
    }

    public abstract class RewiredPlayerGetBoolBDAction : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = false;
        }

        protected TaskStatus UpdateStoreValue(bool newValue) {
            if(newValue != storeValue.Value) { // value changed
                // Store new value
                storeValue.Value = newValue;
            }

            return TaskStatus.Success;
        }
    }

    public abstract class RewiredPlayerActionGetAxis2DBDAction : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a Vector2 variable.")]
        public SharedVector2 storeValue;

        [Tooltip("The Action name string for the X axis value. Must match Action name exactly in the Rewired Input Manager.")]
        public SharedString actionNameX;

        [Tooltip("The Action name string for the Y axis value. Must match Action name exactly in the Rewired Input Manager.")]
        public SharedString actionNameY;

        public override void OnReset() {
            base.OnReset();
            storeValue = Vector2.zero;
            actionNameX = string.Empty;
            actionNameY = string.Empty;
        }

        protected TaskStatus UpdateStoreValue(Vector2 newValue) {
            if(newValue != storeValue.Value) { // value changed
                // Store new value
                storeValue.Value = newValue;
            }

            return TaskStatus.Success;
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(actionNameX.IsNone || string.IsNullOrEmpty(actionNameX.Value) || ReInput.mapping.GetActionId(actionNameX.Value) < 0) {
                Debug.LogError("Invalid Rewired Action (X) name \"" + actionNameX.Value + "\"!");
                return false;
            }
            if(actionNameY.IsNone || string.IsNullOrEmpty(actionNameY.Value) || ReInput.mapping.GetActionId(actionNameY.Value) < 0) {
                Debug.LogError("Invalid Rewired Action (Y) name \"" + actionNameX.Value + "\"!");
                return false;
            }

            return true;
        }
    }

    public abstract class RewiredPlayerInputBehaviorBDAction : RewiredPlayerBDAction {

        [Tooltip("Input Behavior name string.")]
        public SharedString behaviorName;

        public InputBehavior Behavior {
            get {
                return Player.controllers.maps.GetInputBehavior(behaviorName.Value);
            }
        }

        public override void OnReset() {
            base.OnReset();
            behaviorName = string.Empty;
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(behaviorName.IsNone || string.IsNullOrEmpty(behaviorName.Value) || ReInput.mapping.GetActionId(behaviorName.Value) < 0) {
                Debug.LogError("Invalid Input Behavior name \"" + behaviorName.Value + "\"!");
                return false;
            }

            return true;
        }
    }

    #endregion

    #region Player Properties

    [TaskCategory("Rewired/Player")]
    [TaskDescription("The descriptive name of the Player.")]
    public class RewiredPlayerGetName : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a string variable.")]
        public SharedString storeValue;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            storeValue.Value = Player.name;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player")]
    [TaskDescription("The scripting name of the Player.")]
    public class RewiredPlayerGetDescriptiveName : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a string variable.")]
        public SharedString storeValue;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            storeValue.Value = Player.descriptiveName;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player")]
    [TaskDescription("Is this Player currently playing?")]
    public class RewiredPlayerGetIsPlaying : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            storeValue.Value = Player.isPlaying;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player")]
    [TaskDescription("Sets whether this Player currently playing.")]
    public class RewiredPlayerSetIsPlaying : RewiredPlayerBDAction {

        [Tooltip("Sets the boolean value.")]
        public SharedBool value;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            Player.isPlaying = value.Value;
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Get Axis

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the axis value of an Action.")]
    public class RewiredPlayerGetAxis : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxis(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the axis value of an Action during the previous frame.")]
    public class RewiredPlayerGetAxisPrev : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisPrev(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the raw axis value of an Action. The raw value excludes any digital axis simulation modification by the Input Behavior assigned to this Action. This raw value is modified by deadzone and axis calibration settings in the controller. To get truly raw values, you must get the raw value directly from the Controller element.")]
    public class RewiredPlayerGetAxisRaw : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisRaw(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the raw axis value of an Action during the previous frame. The raw value excludes any digital axis simulation modification by the Input Behavior assigned to this Action. This raw value is modified by deadzone and axis calibration settings in the controller. To get truly raw values, you must get the raw value directly from the Controller element.")]
    public class RewiredPlayerGetAxisRawPrev : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisRawPrev(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that an axis has been continuously active as calculated from the raw value. Returns 0 if the axis is not currently active.")]
    public class RewiredPlayerGetAxisTimeActive : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisTimeActive(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that an axis has been inactive as calculated from the raw value. Returns 0 if the axis is currently active.")]
    public class RewiredPlayerGetAxisTimeInactive : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisTimeInactive(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that an axis has been continuously active as calculated from the raw value. Returns 0 if the axis is not currently active.")]
    public class RewiredPlayerGetAxisRawTimeActive : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisRawTimeActive(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that an axis has been inactive as calculated from the raw value. Returns 0 if the axis is currently active.")]
    public class RewiredPlayerGetAxisRawTimeInactive : RewiredPlayerActionGetFloatBDAction {
        
        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxisRawTimeInactive(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the axis value of two Actions.")]
    public class RewiredPlayerGetAxis2d : RewiredPlayerActionGetAxis2DBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxis2D(actionNameX.Value, actionNameY.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the axis value of two Actions during the previous frame. ")]
    public class RewiredPlayerGetAxis2dPrev : RewiredPlayerActionGetAxis2DBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxis2DPrev(actionNameX.Value, actionNameY.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the raw axis value of two Actions. The raw value excludes any digital axis simulation modification by the Input Behavior assigned to this Action. This raw value is modified by deadzone and axis calibration settings in the controller. To get truly raw values, you must get the raw value directly from the Controller element.")]
    public class RewiredPlayerGetAxis2dRaw : RewiredPlayerActionGetAxis2DBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxis2DRaw(actionNameX.Value, actionNameY.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the raw axis value of two Actions during the previous frame. The raw value excludes any digital axis simulation modification by the Input Behavior assigned to this Action. This raw value is modified by deadzone and axis calibration settings in the controller. To get truly raw values, you must get the raw value directly from the Controller element.")]
    public class RewiredPlayerGetAxis2dRawPrev : RewiredPlayerActionGetAxis2DBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAxis2DRawPrev(actionNameX.Value, actionNameY.Value));
        }
    }

    #endregion

    #region Get Button

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button held state of an Action. This will return TRUE as long as the button is held. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetButton : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButton(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button just pressed state of an Action. This will only return TRUE only on the first frame the button is pressed or for the duration of the Button Down Buffer time limit if set in the Input Behavior assigned to this Action. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetButtonDown : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonDown(actionName.Value));
        }

    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Get the button just released state for an Action. This will only return TRUE for the first frame the button is released. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetButtonUp : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonUp(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button held state of an Action during the previous frame.")]
    public class RewiredPlayerGetButtonPrev : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonPrev(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button double pressed and held state of an Action. This will return TRUE after a double press and the button is then held. The double press speed is set in the Input Behavior assigned to the Action.")]
    public class RewiredPlayerGetButtonDoublePressHold : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonDoublePressHold(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button double pressed state of an Action. This will return TRUE only on the first frame of a double press. The double press speed is set in the Input Behavior assigned to the Action.")]
    public class RewiredPlayerGetButtonDoublePressDown : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonDoublePressDown(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that a button has been continuously held down. Returns 0 if the button is not currently pressed.")]
    public class RewiredPlayerGetButtonTimePressed : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonTimePressed(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that a button has not been pressed. Returns 0 if the button is currently pressed.")]
    public class RewiredPlayerGetButtonTimeUnpressed : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetButtonTimeUnpressed(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button held state of all Actions. This will return TRUE as long as any button is held. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyButton : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyButton());
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button just pressed state of all Actions. This will only return TRUE only on the first frame any button is pressed or for the duration of the Button Down Buffer time limit if set in the Input Behavior assigned to the Action. This will return TRUE each time any button is pressed even if others are being held down. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyButtonDown : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyButtonDown());
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Get the button just released state for all Actions. This will only return TRUE for the first frame the button is released. This will return TRUE each time any button is released even if others are being held down. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyButtonUp : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyButtonUp());
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the button held state of an any Action during the previous frame. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyButtonPrev : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyButtonPrev());
        }
    }

    #endregion

    #region Get Negative Button

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button held state of an Action. This will return TRUE as long as the negative button is held. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetNegativeButton : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButton(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button just pressed state of an Action. This will only return TRUE only on the first frame the negative button is pressed or for the duration of the Button Down Buffer time limit if set in the Input Behavior assigned to this Action. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetNegativeButtonDown : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonDown(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Get the negative button just released state for an Action. This will only return TRUE for the first frame the negative button is released. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetNegativeButtonUp : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonUp(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button held state of an Action during the previous frame.")]
    public class RewiredPlayerGetNegativeButtonPrev : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonPrev(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button double pressed state of an Action. This will return TRUE only on the first frame of a double press. The double press speed is set in the Input Behavior assigned to the Action.")]
    public class RewiredPlayerGetNegativeButtonDoublePressDown : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonDoublePressDown(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button double pressed and held state of an Action. This will return TRUE after a double press and the negative button is then held. The double press speed is set in the Input Behavior assigned to the Action.")]
    public class RewiredPlayerGetNegativeButtonDoublePressHold : RewiredPlayerActionGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonDoublePressHold(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that a negative button has been continuously held down. Returns 0 if the negative button is not currently pressed.")]
    public class RewiredPlayerGetNegativeButtonTimePressed : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonTimePressed(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the length of time in seconds that a negative button has not been pressed. Returns 0 if the negative button is currently pressed.")]
    public class RewiredPlayerGetNegativeButtonTimeUnpressed : RewiredPlayerActionGetFloatBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetNegativeButtonTimeUnpressed(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button held state of all Actions. This will return TRUE as long as any negative button is held. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyNegativeButton : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyNegativeButton());
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button just pressed state of all Actions. This will only return TRUE only on the first frame any negative button is pressed or for the duration of the Button Down Buffer time limit if set in the Input Behavior assigned to the Action. This will return TRUE each time any negative button is pressed even if others are being held down. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyNegativeButtonDown : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyNegativeButtonDown());
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Get the negative button just released state for all Actions. This will only return TRUE for the first frame the negative button is released. This will return TRUE each time any negative button is released even if others are being held down. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyNegativeButtonUp : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyNegativeButtonUp());
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Gets the negative button held state of an any Action during the previous frame. This also applies to axes being used as buttons.")]
    public class RewiredPlayerGetAnyNegativeButtonPrev : RewiredPlayerGetBoolBDAction {

        public override TaskStatus DoUpdate() {
            return UpdateStoreValue(Player.GetAnyNegativeButtonPrev());
        }
    }

    #endregion

    #region Vibration

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Sets vibration level for a motor at a specified index on controllers assigned to this Player.")]
    public class RewiredPlayerSetAllControllerVibration : RewiredPlayerBDAction {

        [Tooltip("Sets the vibration motor level. [0 - 1]")]
        public SharedFloat motorLevel;

        [Tooltip("The index of the motor to vibrate.")]
        public SharedInt motorIndex;

        [Tooltip("Stop all other motors except this one.")]
        public SharedBool stopOtherMotors;

        public override void OnReset() {
            base.OnReset();
            motorLevel = 0.0f;
            motorIndex = 0;
            stopOtherMotors = false;
        }

        public override TaskStatus DoUpdate() {
            if(motorIndex.Value < 0) return TaskStatus.Failure;
            motorLevel.Value = Mathf.Clamp01(motorLevel.Value);

            int joystickCount = Player.controllers.joystickCount;
            IList<Joystick> joysticks = Player.controllers.Joysticks;
            for(int i = 0; i < joystickCount; i++) {
                Joystick joystick = joysticks[i];
                if(!joystick.supportsVibration) continue;
                if(motorIndex.Value >= joystick.vibrationMotorCount) continue;
                joystick.SetVibration(motorIndex.Value, motorLevel.Value, stopOtherMotors.Value);
            }
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Stops vibration on all controllers assigned to this Player.")]
    public class RewiredPlayerStopAllControllerVibration : RewiredPlayerBDAction {

        public override TaskStatus DoUpdate() {
            int joystickCount = Player.controllers.joystickCount;
            IList<Joystick> joysticks = Player.controllers.Joysticks;
            for(int i = 0; i < joystickCount; i++) {
                Joystick joystick = joysticks[i];
                if(!joystick.supportsVibration) continue;
                joystick.StopVibration();
            }
            return TaskStatus.Success;
        }
    }

    #endregion

    #region ControllerHelper

    [TaskCategory("Rewired/Player/Controllers")]
    [TaskDescription("Is the mouse assigned to this Player?")]
    public class RewiredPlayerGetHasMouse : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            storeValue.Value = Player.controllers.hasMouse;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/Controllers")]
    [TaskDescription("Sets whether the mouse is assigned to this Player.")]
    public class RewiredPlayerSetHasMouse : RewiredPlayerBDAction {

        [Tooltip("Sets the boolean value.")]
        public SharedBool value;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            Player.controllers.hasMouse = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/Controllers")]
    [TaskDescription("The number of joysticks assigned to this Player.")]
    public class RewiredPlayerGetJoystickCount : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            storeValue.Value = Player.controllers.joystickCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/Controllers")]
    [TaskDescription("The number of Custom Controllers assigned to this Player.")]
    public class RewiredPlayerGetCustomControllerCount : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
        }

        public override TaskStatus DoUpdate() {
            storeValue.Value = Player.controllers.customControllerCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/Controllers")]
    [TaskDescription("Unassign controllers from this Player.")]
    public class RewiredPlayerRemoveControllers : RewiredPlayerBDAction {

        [Tooltip("Remove only controllers of a certain type. If false, all assignable controllers will be removed.")]
        public SharedBool byControllerType;

        [Tooltip("Controller type to remove from Player. Not used if Clear By Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Joystick;

        public override void OnReset() {
            base.OnReset();
            byControllerType = false;
            controllerType = ControllerType.Joystick;
        }

        public override TaskStatus DoUpdate() {
            if(byControllerType.Value) {
                Player.controllers.ClearControllersOfType(controllerType);
            } else {
                Player.controllers.ClearAllControllers();
            }
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/Controllers")]
    [TaskDescription("Get the last controller type that contributed input through the Player.")]
    public class RewiredPlayerGetLastActiveControllerType : RewiredPlayerBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0;
        }

        public override TaskStatus DoUpdate() {
            Controller controller = Player.controllers.GetLastActiveController();
            if(controller == null) {
                storeValue.Value = 0;
                return TaskStatus.Failure;
            }
            storeValue.Value = (int)controller.type;
            
            return TaskStatus.Success;
        }
    }

    #endregion

    #region MapHelper

    [TaskCategory("Rewired/Player/Maps")]
    [TaskDescription("Set the enabled state in all maps in a particular category and/or layout.")]
    public class RewiredPlayerSetControllerMapsEnabled : RewiredPlayerBDAction {

        [Tooltip("Set the enabled state.")]
        public SharedBool enabledState;

        [Tooltip("The Controller Map category name.")]
        public SharedString categoryName;

        [Tooltip("The Controller Map layout name. [Optional]")]
        public SharedString layoutName;

        [Tooltip("Set the enabled state of maps for a particular controller type.")]
        public SharedBool byControllerType;

        [Tooltip("Set the enabled state of maps for a particular controller type. Not used if Set By Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Joystick;

        public override void OnReset() {
            base.OnReset();
            categoryName = string.Empty;
            layoutName = string.Empty;
            byControllerType = false;
            controllerType = ControllerType.Joystick;
        }

        public override TaskStatus DoUpdate() {
            SetMapsEnabled();
            return TaskStatus.Success;
        }

        private void SetMapsEnabled() {
            if(byControllerType.Value) {
                SetMapsEnabled(enabledState.Value, controllerType, categoryName.Value, layoutName.Value);
            } else {
                SetMapsEnabled(enabledState.Value, categoryName.Value, layoutName.Value);
            }
        }

        private void SetMapsEnabled(bool state, ControllerType controllerType, string categoryName, string layoutName) {
            if(string.IsNullOrEmpty(layoutName)) Player.controllers.maps.SetMapsEnabled(state, controllerType, categoryName);
            else Player.controllers.maps.SetMapsEnabled(state, controllerType, categoryName, layoutName);
        }

        private void SetMapsEnabled(bool state, string categoryName, string layoutName) {
            if(string.IsNullOrEmpty(layoutName)) Player.controllers.maps.SetMapsEnabled(state, categoryName);
            else Player.controllers.maps.SetMapsEnabled(state, categoryName, layoutName);
        }
    }

    [TaskCategory("Rewired/Player/Maps")]
    [TaskDescription("Set the enabled state in all controller maps.")]
    public class RewiredPlayerSetAllControllerMapsEnabled : RewiredPlayerBDAction {

        [Tooltip("Set the enabled state.")]
        public SharedBool enabledState;

        [Tooltip("Set the enabled state of maps for a particular controller type.")]
        public SharedBool byControllerType;

        [Tooltip("Set the enabled state of maps for a particular controller type. Not used if Set By Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Joystick;

        public override void OnReset() {
            base.OnReset();
            byControllerType = false;
            controllerType = ControllerType.Joystick;
        }

        public override TaskStatus DoUpdate() {
            SetMapsEnabled();
            return TaskStatus.Success;
        }

        private void SetMapsEnabled() {
            if(byControllerType.Value) {
                Player.controllers.maps.SetAllMapsEnabled(enabledState.Value, controllerType);
            } else {
                Player.controllers.maps.SetAllMapsEnabled(enabledState.Value);
            }
        }
    }

    #endregion

    #region Input Behaviors

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetDigitalAxisGravity : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.digitalAxisGravity;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetDigitalAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.digitalAxisSensitivity;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetDigitalAxisSnap : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = false;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.digitalAxisSnap;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetDigitalAxisInstantReverse : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = false;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.digitalAxisInstantReverse;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetJoystickAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.joystickAxisSensitivity;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetCustomControllerAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.customControllerAxisSensitivity;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetMouseXYAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.mouseXYAxisSensitivity;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetMouseOtherAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.mouseOtherAxisSensitivity;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetMouseOtherAxisMode : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = (int)Behavior.mouseOtherAxisMode;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetMouseXYAxisDeltaCalc : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = (int)Behavior.mouseXYAxisDeltaCalc;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetMouseXYAxisMode : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = (int)Behavior.mouseXYAxisMode;
            return TaskStatus.Success;
        }
    }


    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetButtonDeadZone : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.buttonDeadZone;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetButtonDoublePressSpeed : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.buttonDoublePressSpeed;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorGetButtonDownBuffer : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            storeValue.Value = Behavior.buttonDownBuffer;
            return TaskStatus.Success;
        }
    }

    // Set

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetDigitalAxisGravity : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.digitalAxisGravity = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetDigitalAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.digitalAxisSensitivity = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetDigitalAxisSnap : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedBool value;

        public override void OnReset() {
            base.OnReset();
            value = false;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.digitalAxisSnap = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetDigitalAxisInstantReverse : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedBool value;

        public override void OnReset() {
            base.OnReset();
            value = false;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.digitalAxisInstantReverse = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetJoystickAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.joystickAxisSensitivity = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetCustomControllerAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.customControllerAxisSensitivity = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetMouseXYAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.mouseXYAxisSensitivity = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetMouseOtherAxisSensitivity : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.mouseOtherAxisSensitivity = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetMouseOtherAxisMode : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt value;

        public override void OnReset() {
            base.OnReset();
            value = 0;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.mouseOtherAxisMode = (MouseOtherAxisMode)value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetMouseXYAxisDeltaCalc : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt value;

        public override void OnReset() {
            base.OnReset();
            value = 0;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.mouseXYAxisDeltaCalc = (MouseXYAxisDeltaCalc)value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetMouseXYAxisMode : RewiredPlayerInputBehaviorBDAction {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt value;

        public override void OnReset() {
            base.OnReset();
            value = 0;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.mouseXYAxisMode = (MouseXYAxisMode)value.Value;
            return TaskStatus.Success;
        }
    }


    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetButtonDeadZone : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.buttonDeadZone = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetButtonDoublePressSpeed : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.buttonDoublePressSpeed = value.Value;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Player/InputBehaviors")]
    public class RewiredPlayerInputBehaviorSetButtonDownBuffer : RewiredPlayerInputBehaviorBDAction {

        [Tooltip("Set the value.")]
        public SharedFloat value;

        public override void OnReset() {
            base.OnReset();
            value = 0.0f;
        }

        public override TaskStatus DoUpdate() {
            if(Behavior == null) return TaskStatus.Failure;
            Behavior.buttonDownBuffer = value.Value;
            return TaskStatus.Success;
        }
    }

    #endregion

    // Conditionals

    #region Base Classes

    public abstract class RewiredPlayerBDConditional : Conditional {

        [Tooltip("The Rewired Player Id. To use the System Player, enter any value < 0 or 9999999.")]
        public SharedInt playerId;

        protected Player Player {
            get {
                if(playerId.Value < 0 || playerId.Value == Rewired.Consts.systemPlayerId) return ReInput.players.GetSystemPlayer();
                return ReInput.players.GetPlayer(playerId.Value);
            }
        }

        public override void OnReset() {
            base.OnReset();
            playerId = 0;
        }

        public override TaskStatus OnUpdate() {
            if(!ValidateVars()) return TaskStatus.Failure;
            return DoUpdate();
        }

        public abstract TaskStatus DoUpdate();

        protected virtual bool ValidateVars() {
            if(playerId.IsNone) {
                Debug.LogError("Rewired Player Id must be assigned!");
                return false;
            }
            if(playerId.Value != Rewired.Consts.systemPlayerId && playerId.Value >= ReInput.players.playerCount) {
                Debug.LogError("Rewired Player Id is out of range!");
                return false;
            }
            return true;
        }
    }

    public abstract class RewiredPlayerActionBDConditional : RewiredPlayerBDConditional {

        [Tooltip("The Action name string. Must match Action name exactly in the Rewired Input Manager.")]
        public SharedString actionName;

        public override void OnReset() {
            base.OnReset();
            actionName = string.Empty;
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;

            if(actionName.IsNone || string.IsNullOrEmpty(actionName.Value) || ReInput.mapping.GetActionId(actionName.Value) < 0) {
                Debug.LogError("Invalid Rewired Action name\"" + actionName.Value + "\"!");
                return false;
            }
            return true;
        }
    }

    public abstract class RewiredPlayerActionCompareFloatBDConditional : RewiredPlayerActionBDConditional {

        [Tooltip("The comparison operation to perform")]
        public CompareOperation operation;
        [Tooltip("The value to which to compare the returned value.")]
        public SharedFloat compareToValue;
        [Tooltip("Compare using the absolute values of the two operands.")]
        public SharedBool useAbsValues;

        public override void OnReset() {
            base.OnReset();
            operation = CompareOperation.None;
            compareToValue.Value = 0;
            useAbsValues = false;
        }

        protected TaskStatus Compare(float value) {
            if(operation == CompareOperation.None) return TaskStatus.Success;

            float val1, val2;
            if(useAbsValues.Value) {
                val1 = Mathf.Abs(value);
                val2 = Mathf.Abs(compareToValue.Value);
            } else {
                val1 = value;
                val2 = compareToValue.Value;
            }

            switch(operation) {
                case CompareOperation.LessThan:
                    return val1 < val2 ? TaskStatus.Success : TaskStatus.Failure;
                case CompareOperation.LessThanOrEqualTo:
                    return val1 <= val2 ? TaskStatus.Success : TaskStatus.Failure;
                case CompareOperation.EqualTo:
                    return val1 == val2 ? TaskStatus.Success : TaskStatus.Failure;
                case CompareOperation.NotEqualTo:
                    return val1 != val2 ? TaskStatus.Success : TaskStatus.Failure;
                case CompareOperation.GreaterThanOrEqualTo:
                    return val1 >= val2 ? TaskStatus.Success : TaskStatus.Failure;
                case CompareOperation.GreaterThan:
                    return val1 > val2 ? TaskStatus.Success : TaskStatus.Failure;
            }
            return TaskStatus.Failure;
        }
    }

    #endregion

    #region Button States

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the button just pressed state of an Action. This will only return TRUE only on the first frame the button is pressed or for the duration of the Button Down Buffer time limit if set in the Input Behavior assigned to this Action. This also applies to axes being used as buttons.")]
    public class RewiredPlayerButtonJustPressed : RewiredPlayerActionBDConditional {

        public override TaskStatus DoUpdate() {
            return Player.GetButtonDown(actionName.Value) ? TaskStatus.Success : TaskStatus.Failure;
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the button just released state for an Action. This will only return TRUE for the first frame the button is released. This also applies to axes being used as buttons.")]
    public class RewiredPlayerButtonJustReleased : RewiredPlayerActionBDConditional {

        public override TaskStatus DoUpdate() {
            return Player.GetButtonUp(actionName.Value) ? TaskStatus.Success : TaskStatus.Failure;
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the button held state of an Action. This will return TRUE as long as the button is held. This also applies to axes being used as buttons.")]
    public class RewiredPlayerButtonHeld : RewiredPlayerActionBDConditional {

        public override TaskStatus DoUpdate() {
            return Player.GetButton(actionName.Value) ? TaskStatus.Success : TaskStatus.Failure;
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the negative button just pressed state of an Action. This will only return TRUE only on the first frame the negative button is pressed or for the duration of the Button Down Buffer time limit if set in the Input Behavior assigned to this Action. This also applies to axes being used as buttons.")]
    public class RewiredPlayerNegativeButtonJustPressed : RewiredPlayerActionBDConditional {

        public override TaskStatus DoUpdate() {
            return Player.GetNegativeButtonDown(actionName.Value) ? TaskStatus.Success : TaskStatus.Failure;
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the negative button just released state for an Action. This will only return TRUE for the first frame the negative button is released. This also applies to axes being used as buttons.")]
    public class RewiredPlayerNegativeButtonJustReleased : RewiredPlayerActionBDConditional {

        public override TaskStatus DoUpdate() {
            return Player.GetNegativeButtonUp(actionName.Value) ? TaskStatus.Success : TaskStatus.Failure;
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the negative button held state of an Action. This will return TRUE as long as the negative button is held. This also applies to axes being used as buttons.")]
    public class RewiredPlayerNegativeButtonHeld : RewiredPlayerActionBDConditional {

        public override TaskStatus DoUpdate() {
            return Player.GetNegativeButton(actionName.Value) ? TaskStatus.Success : TaskStatus.Failure;
        }
    }

    #endregion

    #region Axis States

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the the axis value of an Action.")]
    public class RewiredPlayerCompareAxis : RewiredPlayerActionCompareFloatBDConditional {

        public override TaskStatus DoUpdate() {
            return Compare(Player.GetAxis(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the the previous axis value of an Action.")]
    public class RewiredPlayerCompareAxisPrev : RewiredPlayerActionCompareFloatBDConditional {

        public override TaskStatus DoUpdate() {
            return Compare(Player.GetAxisPrev(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the the raw axis value of an Action.")]
    public class RewiredPlayerCompareAxisRaw : RewiredPlayerActionCompareFloatBDConditional {

        public override TaskStatus DoUpdate() {
            return Compare(Player.GetAxisRaw(actionName.Value));
        }
    }

    [TaskCategory("Rewired/Player/Input")]
    [TaskDescription("Evaluates the the previous raw axis value of an Action.")]
    public class RewiredPlayerCompareAxisRawPrev : RewiredPlayerActionCompareFloatBDConditional {

        public override TaskStatus DoUpdate() {
            return Compare(Player.GetAxisRawPrev(actionName.Value));
        }
    }

    #endregion
}